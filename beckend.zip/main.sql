CREATE TABLE users (
    id       SERIAL PRIMARY KEY,
    email    VARCHAR NOT NULL,
    password VARCHAR NOT NULL,
    created  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status   VARCHAR CHECK (status IN ('verify', 'null')) DEFAULT 'null',
    attempts SMALLINT CHECK (attempts >= 0) DEFAULT 3,
    tg_id    BIGINT UNIQUE,          -- Telegram ID
    UNIQUE (email)
);

CREATE INDEX ix_users_email ON users (email);