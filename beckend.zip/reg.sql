CREATE TABLE traders (
    id SERIAL PRIMARY KEY,
    trader_id VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NULL
);