import asyncio
from fastapi import FastAPI, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from fastapi.middleware.cors import CORSMiddleware
import re
import base64
from .database import engine, get_db, Base
from .models import User,Tradeer
from .schemas import UserCreate, UserOut, Token, AnalyseOut, AnalyseRequest, TraderRequest
from .security import hash_password, verify_password, create_access_token
from .deps import get_current_user
from fastapi.middleware.cors import CORSMiddleware
from .deepseek_utils import analyse_image

app = FastAPI(title="Async Auth API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "https://aitrader22.pages.dev",   # ← no slash, no space
        "https://aitrader33.pages.dev",
        "https://aitrader56.pages.dev"
    ],
    allow_credentials=True,
    allow_methods=["*"],        # or list the verbs you really use
    allow_headers=["*"],
)

@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.post("/signup", response_model=Token, status_code=status.HTTP_201_CREATED)
async def register(
    payload: UserCreate,
    db: AsyncSession = Depends(get_db)
):
    stmt = select(User).where(User.email == payload.email)
    res = await db.execute(stmt)
    if res.first():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(
        email=payload.email,
        password=hash_password(payload.password)
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    print(user.id)
    token = create_access_token(data={"sub": str(user.id)})
    return Token(access_token=token,email=payload.email)

@app.post("/login", response_model=Token)
async def login(
    payload: UserCreate,          # теперь используем только email + password
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(select(User).where(User.email == payload.email))
    user = res.scalar_one_or_none()
    if not user or not verify_password(payload.password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    token = create_access_token(data={"sub": str(user.id)})
    return Token(access_token=token,email=payload.email)

@app.get("/me", response_model=UserOut)
async def me(current: User = Depends(get_current_user)):
    return current

@app.post("/analyze", response_model=AnalyseOut)
async def analyse(
    payload: AnalyseRequest,
    current: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(select(User).where(User.email == payload.email))
    user = res.scalar_one_or_none()
    has_active_status = user.status != "verify"
    print(has_active_status)
    if not user:
        raise HTTPException(404, "User not found")

    # 2. проверяем лимит
    if user.attempts <= 0 and has_active_status:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Analysis limit exceeded. PLS Register."
        )

    # 3. основная логика
    data_url: str = payload.image
    match = re.fullmatch(r"data:(image/\w+);base64,(.+)", data_url.strip())
    if not match:
        raise HTTPException(400, "Invalid data-url format")
    mime, b64 = match.groups()
    if mime not in ("image/png", "image/jpeg", "image/webp"):
        raise HTTPException(400, "Only JPEG/PNG/WebP allowed")

    image_bytes = base64.b64decode(b64)
    answer = await analyse_image(image_bytes)

    # 4. списываем попытку
    if(has_active_status):
        user.attempts -= 1
        await db.commit()

    return AnalyseOut(answer=answer)

@app.post("/register-id", response_model=AnalyseOut)
async def register_trader_id(
    payload: TraderRequest,
    current: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # 1. Ищем трейдера в таблице traders по trader_id
    trader_stmt = select(Tradeer).where(Tradeer.trader_id == payload.id)
    trader_result = await db.execute(trader_stmt)
    trader = trader_result.scalar_one_or_none()
    
    if not trader:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Trader with ID {payload.id} not found"
        )
    
    # 2. Проверяем, есть ли уже email у трейдера
    if trader.email is not None and trader.email != "":
        # Если email уже есть, возможно, нужно проверить, совпадает ли он с текущим
        if trader.email != payload.email:
            # Можно выбрать стратегию: разрешить изменение или запретить
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This trader ID is already associated with another email"
            )
        # Если email совпадает, просто продолжаем
    else:
        # 3. Если email пустой - добавляем email из запроса
        if payload.email is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email cannot be null when registering trader ID"
            )
        
        trader.email = payload.email
        await db.commit()
        await db.refresh(trader)
    
    # 4. Ищем пользователя в таблице users по email
    user_stmt = select(User).where(User.email == payload.email)
    user_result = await db.execute(user_stmt)
    user = user_result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with email {payload.email} not found"
        )
    
    # 5. Обновляем статус пользователя на "verify"
    if user.status != "verify":
        user.status = "verify"
        user.attempts = 10  # Устанавливаем количество попыток, например, 10 или любое другое значение по умолчанию
        await db.commit()
        await db.refresh(user)
    
    return AnalyseOut(answer="ok")

@app.get("/regpost")
async def handle_regpost(
    request: Request, # FastAPI предоставляет объект запроса
    event: str,       # Извлекаем параметр event из строки запроса
    trader_id: str,      # Извлекаем параметр trader из строки запроса
    db: AsyncSession = Depends(get_db)
):
    print(request)
    print(event)
    if event == "reg":
        existing_user_stmt = select(Tradeer).where(Tradeer.trader_id == trader_id)
        res = await db.execute(existing_user_stmt)
        existing_user = res.scalar_one_or_none()
        if existing_user:
            print(f"Trader {trader_id} already exists in DB.")
        else:
            new_user = Tradeer(
                trader_id=trader_id,
            )
            db.add(new_user)
            try:
                await db.commit()
                print(f"New trader {trader_id} added to DB.")
            except Exception as e:
                await db.rollback()
                print(f"Error adding trader {trader_id}: {e}")
                raise HTTPException(status_code=500, detail="Failed to register trader.")
            
    print(f"Received registration request for trader: {trader_id}")
    return {"status": "ok"}
@app.get("/regqui")
async def handle_regpost(
    request: Request, # FastAPI предоставляет объект запроса
    event: str,       # Извлекаем параметр event из строки запроса
    uid: str,      # Извлекаем параметр trader из строки запроса
    db: AsyncSession = Depends(get_db)
):
    print(request)
    print(event)
    if event == "reg":
        existing_user_stmt = select(Tradeer).where(Tradeer.trader_id == uid)
        res = await db.execute(existing_user_stmt)
        existing_user = res.scalar_one_or_none()
        if existing_user:
            print(f"Trader {uid} already exists in DB.")
        else:
            new_user = Tradeer(
                trader_id=uid,
            )
            db.add(new_user)
            try:
                await db.commit()
                print(f"New trader {uid} added to DB.")
            except Exception as e:
                await db.rollback()
                print(f"Error adding trader {uid}: {e}")
                raise HTTPException(status_code=500, detail="Failed to register trader.")
            
    print(f"Received registration request for trader: {uid}")
    return {"status": "ok"}