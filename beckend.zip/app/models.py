from sqlalchemy import Column, Integer, String, DateTime, func, SmallInteger, BigInteger
from .database import Base

class User(Base):
    __tablename__ = "users"

    id       = Column(Integer, primary_key=True, index=True)
    email    = Column(String, unique=True, index=True, nullable=False)
    password = Column(String, nullable=False)
    created  = Column(DateTime(timezone=True), server_default=func.now())
    status   = Column(String, server_default='null')          # новое
    attempts = Column(SmallInteger, server_default='3')       # новое
    tg_id    = Column(BigInteger, unique=True, nullable=True) # новое


class Tradeer(Base):
    __tablename__ = "traders" # Имя таблицы, которое мы создавали ранее

    id = Column(Integer, primary_key=True, index=True)
    trader_id = Column(String, unique=True, index=True, nullable=False) # Уникальный trader_id
    email = Column(String, nullable=True)