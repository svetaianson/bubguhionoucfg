import asyncio
from fastapi import FastAPI, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import re
import base64
from .database import engine, get_db, Base
from .models import User,Tradeer
from .schemas import UserCreate, UserOut, Token, AnalyseOut, AnalyseRequest, TraderRequest
from .security import hash_password, verify_password, create_access_token
from .deps import get_current_user
from fastapi.middleware.cors import CORSMiddleware
from .deepseek_utils import analyse_image

app = FastAPI(title="Async Auth API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "https://aitrader22.pages.dev",   # ← no slash, no space
        "https://aitrader33.pages.dev",
        "https://aitrader56.pages.dev",
        "https://xkdjndjnmjkm.pages.dev"
    ],
    allow_credentials=True,
    allow_methods=["*"],        # or list the verbs you really use
    allow_headers=["*"],
)

@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.post("/signup", response_model=Token, status_code=status.HTTP_201_CREATED)
async def register(
    payload: UserCreate,
    db: AsyncSession = Depends(get_db)
):
    stmt = select(User).where(User.email == payload.email)
    res = await db.execute(stmt)
    if res.first():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(
        email=payload.email,
        password=hash_password(payload.password)
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    print(user.id)
    token = create_access_token(data={"sub": str(user.id)})
    return Token(access_token=token,email=payload.email)

@app.post("/login", response_model=Token)
async def login(
    payload: UserCreate,
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(select(User).where(User.email == payload.email))
    user = res.scalar_one_or_none()
    
    # Проверка: пользователь не существует
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You are not registered"
        )
    
    # Проверка: неверный пароль
    if not verify_password(payload.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect email or password"
        )

    token = create_access_token(data={"sub": str(user.id)})
    return Token(access_token=token, email=payload.email)

@app.get("/me", response_model=UserOut)
async def me(current: User = Depends(get_current_user)):
    return current

@app.post("/analyze", response_model=AnalyseOut)
async def analyse(
    payload: AnalyseRequest,
    current: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(select(User).where(User.email == payload.email))
    user = res.scalar_one_or_none()
    has_active_status = user.status != "verify"
    print(has_active_status)
    if not user:
        raise HTTPException(404, "User not found")

    # 2. проверяем лимит
    if user.attempts <= 0 and has_active_status:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Analysis limit exceeded. PLS Register."
        )

    # 3. основная логика
    data_url: str = payload.image
    match = re.fullmatch(r"data:(image/\w+);base64,(.+)", data_url.strip())
    if not match:
        raise HTTPException(400, "Invalid data-url format")
    mime, b64 = match.groups()
    if mime not in ("image/png", "image/jpeg", "image/webp"):
        raise HTTPException(400, "Only JPEG/PNG/WebP allowed")

    image_bytes = base64.b64decode(b64)
    answer = await analyse_image(image_bytes)

    # 4. списываем попытку
    if(has_active_status):
        user.attempts -= 1
        await db.commit()

    return AnalyseOut(answer=answer)

@app.post("/register-id", response_model=AnalyseOut)
async def register_trader_id(
    payload: TraderRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Регистрирует trader_id за пользователем при условии, что:
    1. Trader существует в таблице traders
    2. Баланс (money) >= 50
    3. Обновляет email в traders и статус в users
    """
    
    # Шаг 1: Проверяем существование trader
    trader_stmt = select(Tradeer).where(Tradeer.trader_id == payload.id).with_for_update()
    trader_result = await db.execute(trader_stmt)
    trader = trader_result.scalar_one_or_none()
    
    if not trader:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Trader ID {payload.id} not found"
        )
    
    # Шаг 2: Проверяем баланс >= 50
    if trader.money < 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You haven't topped up $50"
        )
    
    # Шаг 3: Валидируем email (должен быть передан)
    if not payload.email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is required"
        )
    
    # Шаг 4: Обновляем email в таблице traders (если нужно)
    if trader.email != payload.email:
        trader.email = payload.email
        await db.flush()
    
    # Шаг 5: Обновляем статус и attempts пользователя
    # Используем current_user.id для безопасности (вместо поиска по email)
    user_update_stmt = (
        update(User)
        .where(User.id == current_user.id)
        .values(
            status="verify",
            attempts=10
        )
        .returning(User.id, User.email, User.status)
    )
    
    try:
        result = await db.execute(user_update_stmt)
        updated_user = result.fetchone()
        
        if not updated_user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Фиксируем все изменения
        await db.commit()
        await db.refresh(trader)
        
        return AnalyseOut(answer="ok")
        
    except HTTPException:
        await db.rollback()
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update user data: {e}"
        )

@app.get("/regpost")  # Изменил на POST - более правильно для создания ресурса
async def handle_regpost(
    request: Request,
    event: str,
    trader_id: str,
    money: int,
    db: AsyncSession = Depends(get_db)
):
    if event == "reg":
        # Проверяем существование
        existing_user_stmt = select(Tradeer).where(Tradeer.trader_id == trader_id)
        result = await db.execute(existing_user_stmt)
        existing_user = result.scalar_one_or_none()
        
        if existing_user:
            print(f"Trader {trader_id} already exists in DB.")
            return {"status": "exists", "message": "Trader already registered"}
        
        # Создаем нового трейдера
        new_user = Tradeer(
            trader_id=trader_id,
            money=money  # Явно передаем значение (или будет использоваться DEFAULT 0)
        )
        db.add(new_user)
        
        try:
            await db.commit()
            print(f"New trader {trader_id} added to DB with balance {money}.")
            return {"status": "ok", "trader_id": trader_id, "money": money}
        except Exception as e:
            await db.rollback()
            print(f"Error adding trader {trader_id}: {e}")
            raise HTTPException(status_code=500, detail="Failed to register trader")
    elif event == "money":
        # Проверяем существование
        existing_stmt = select(Tradeer).where(Tradeer.trader_id == trader_id)
        trader = await db.scalar(existing_stmt)
        
        if not trader:
            raise HTTPException(status_code=404, detail="Trader not found")
        
        # Атомарное обновление на уровне БД
        try:
            update_stmt = (
                update(Tradeer)
                .where(Tradeer.trader_id == trader_id)
                .values(money=Tradeer.money + money)  # money = money + 50
                .returning(Tradeer.money)  # Возвращает новое значение
            )
            result = await db.execute(update_stmt)
            await db.commit()
            
            new_balance = result.scalar()
            
            return {
                "status": "ok",
                "trader_id": trader_id,
                "added": money,
                "new_balance": new_balance
            }
        except Exception as e:
            await db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update balance: {e}")
    
    return {"status": "ignored", "message": "Event is not 'reg'"}
@app.get("/regqui")
async def handle_regqui(
    request: Request,
    reg:str,
    uid:str,
    db: AsyncSession = Depends(get_db)
):
    reg = request.query_params.get("reg")
    uid = request.query_params.get("uid", "")
    should_register = str(reg).lower() in ["true", "1", "reg"] if reg else False
    
    if should_register and uid:
        existing_user_stmt = select(Tradeer).where(Tradeer.trader_id == uid)
        res = await db.execute(existing_user_stmt)
        existing_user = res.scalar_one_or_none()
        
        if existing_user:
            print(f"Trader {uid} already exists in DB.")
        else:
            new_user = Tradeer(trader_id=uid)
            db.add(new_user)
            try:
                await db.commit()
                print(f"New trader {uid} added to DB.")
            except Exception as e:
                await db.rollback()
                print(f"Error adding trader {uid}: {e}")
                raise HTTPException(
                    status_code=500, 
                    detail="Database error"
                )
    
    print(f"Processed request: uid={uid}, register={should_register}")
    return {"status": "ok"}
@app.get("/qui")
async def handle_qui(
    request: Request,
    dep: bool,
    uid: str,
    payout: int,
    db: AsyncSession = Depends(get_db)
):
    # Проверяем, что запрос именно на пополнение
    if not dep:
        return {"status": "error", "message": "dep parameter must be true"}
    
    # Находим трейдера по uid
    trader = await db.scalar(select(Tradeer).where(Tradeer.trader_id == uid))
    if not trader:
        raise HTTPException(status_code=404, detail="Trader not found")
    
    # Атомарное обновление баланса
    try:
        update_stmt = (
            update(Tradeer)
            .where(Tradeer.trader_id == uid)
            .values(money=Tradeer.money + payout)
            .returning(Tradeer.money)
        )
        result = await db.execute(update_stmt)
        await db.commit()
        
        new_balance = result.scalar()
        
        return {
            "status": "ok",
            "trader_id": uid,
            "payout": payout,
            "new_balance": new_balance
        }
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to update balance: {e}")
    

@app.get("/q")
async def handle_qui(
    request: Request,
    ftd: bool,
    uid: str,
    payout: int,
    db: AsyncSession = Depends(get_db)
):
    # Проверяем, что запрос именно на пополнение
    if not ftd:
        return {"status": "error", "message": "ftd parameter must be true"}
    
    # Находим трейдера по uid
    trader = await db.scalar(select(Tradeer).where(Tradeer.trader_id == uid))
    if not trader:
        raise HTTPException(status_code=404, detail="Trader not found")
    
    # Атомарное обновление баланса
    try:
        update_stmt = (
            update(Tradeer)
            .where(Tradeer.trader_id == uid)
            .values(money=Tradeer.money + payout)
            .returning(Tradeer.money)
        )
        result = await db.execute(update_stmt)
        await db.commit()
        
        new_balance = result.scalar()
        
        return {
            "status": "ok",
            "trader_id": uid,
            "payout": payout,
            "new_balance": new_balance
        }
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to update balance: {e}")