from sqlalchemy import Column, Integer, String, DateTime, func, SmallInteger, BigInteger, text, FLOAT, ForeignKey, Text
from .database import Base
from datetime import datetime
from sqlalchemy.orm import relationship

class User(Base):
    __tablename__ = "users"

    id       = Column(Integer, primary_key=True, index=True)
    email    = Column(String, unique=True, index=True, nullable=False)
    password = Column(String, nullable=False)
    created  = Column(DateTime(timezone=True), server_default=func.now())
    status   = Column(String, server_default='null')          # новое
    attempts = Column(SmallInteger, server_default='3')       # новое
    tg_id    = Column(BigInteger, unique=True, nullable=True) # новое


class Tradeer(Base):
    __tablename__ = "traders"  # Имя таблицы, которое мы создавали ранее

    id = Column(Integer, primary_key=True, index=True)
    trader_id = Column(String, unique=True, index=True, nullable=False)  # Уникальный trader_id
    email = Column(String, nullable=True)
    money = Column(FLOAT, server_default=text('0'))

class TradingReview(Base):
    __tablename__ = "trading_reviews"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, nullable=False)
    chart_image = Column(String(255), nullable=True)
    chart_notes = Column(String(100), nullable=True)
    analysis_result = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)