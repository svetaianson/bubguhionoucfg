import os
import json
import base64
import mimetypes
import re
import asyncio
from concurrent.futures import ThreadPoolExecutor
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Обязательные scopes для отправки писем
DEFAULT_SCOPES = [
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.metadata"
]

class AsyncGmailService:
    def __init__(self, token_json_str=None, client_secrets_json_str=None, scopes=None):
        """
        Асинхронный сервис Gmail с поддержкой base64 изображений
        
        :param token_json_str: Строка с токеном (для автоматической авторизации)
        :param client_secrets_json_str: Строка с OAuth-данными (только для первого запуска)
        """
        self.scopes = scopes if scopes else DEFAULT_SCOPES
        self.creds = None
        self.service = None
        self.sender_email = None
        self._executor = ThreadPoolExecutor(max_workers=5)
        
        # Синхронная инициализация (токен загружается быстро)
        self._sync_init(token_json_str, client_secrets_json_str)
    
    def _sync_init(self, token_json_str, client_secrets_json_str):
        """Синхронная инициализация для __init__"""
        if token_json_str:
            self._load_token(token_json_str)
        
        if not self.creds and client_secrets_json_str:
            self._get_new_token(client_secrets_json_str)
        
        if not self.creds or not self.creds.valid:
            raise ValueError(
                "Нет действительных учетных данных! "
                "1. При первом запуске укажите client_secrets_json_str\n"
                "2. После авторизации сохраните токен и используйте его в будущем"
            )
        
        self._initialize_service()
    
    def _load_token(self, token_json_str):
        """Загружает и обновляет существующий токен"""
        try:
            token_data = json.loads(token_json_str)
            self.creds = Credentials.from_authorized_user_info(token_data, self.scopes)
            
            if self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
        except Exception as e:
            print(f"Ошибка загрузки токена: {str(e)}")
            self.creds = None
    
    def _get_new_token(self, client_secrets_json_str):
        """Получает НОВЫЙ токен через OAuth"""
        try:
            client_config = json.loads(client_secrets_json_str)
            flow = InstalledAppFlow.from_client_config(
                client_config,
                self.scopes,
                redirect_uri='http://localhost'
            )
            self.creds = flow.run_local_server(
                port=0,
                prompt='consent',
                authorization_prompt_message='Откройте эту ссылку в браузере:\n{url}',
                success_message='✅ Авторизация успешна! Закройте окно браузера.'
            )
        except Exception as e:
            raise Exception(f"Ошибка получения токена: {str(e)}") from e
    
    def _initialize_service(self):
        """Инициализация Gmail API сервиса"""
        self.service = build("gmail", "v1", credentials=self.creds)
        profile = self.service.users().getProfile(userId="me").execute()
        self.sender_email = profile["emailAddress"]
    
    @property
    def token(self):
        """Возвращает актуальный токен в формате JSON"""
        return self.creds.to_json() if self.creds else None
    
    def _is_html(self, text):
        """Проверяет, является ли текст HTML"""
        return bool(re.search(r'<[a-z][\s\S]*>', text, re.IGNORECASE))
    
    def _parse_base64_image(self, data_url):
        """
        Парсит base64 изображение из data URL
        
        :param data_url: Строка вида "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoA..."
        :return: (mime_type, image_bytes, filename)
        """
        try:
            # Извлекаем mime-type и данные
            header, b64_data = data_url.split(',', 1)
            mime_type = header.split(';')[0].split(':', 1)[1]
            
            # Декодируем base64
            image_bytes = base64.b64decode(b64_data)
            
            # Определяем расширение файла
            ext = mimetypes.guess_extension(mime_type) or ".bin"
            ext = ext.replace(".", "")  # Убираем точку
            
            # Генерируем имя файла
            filename = f"image.{ext}"
            
            return mime_type, image_bytes, filename
        except Exception as e:
            raise ValueError(f"Ошибка парсинга base64 изображения: {str(e)}")
    
    def _create_message(self, to, subject, body, image_data=None):
        """Создает MIME-сообщение с возможным изображением"""
        message = MIMEMultipart()
        message["to"] = to
        message["from"] = self.sender_email
        message["subject"] = subject
        
        # Добавляем текст письма
        content_type = "html" if self._is_html(body) else "plain"
        message.attach(MIMEText(body, content_type))
        
        # Добавляем изображение если есть
        if image_data:
            try:
                mime_type, image_bytes, filename = self._parse_base64_image(image_data)
                main_type, sub_type = mime_type.split('/', 1)
                
                if main_type == "image":
                    mime_image = MIMEImage(image_bytes, _subtype=sub_type)
                else:
                    mime_image = MIMEBase(main_type, sub_type)
                    mime_image.set_payload(image_bytes)
                    from email import encoders
                    encoders.encode_base64(mime_image)
                
                mime_image.add_header(
                    "Content-Disposition",
                    "attachment",
                    filename=filename
                )
                message.attach(mime_image)
            except Exception as e:
                print(f"⚠️ Ошибка при добавлении изображения: {str(e)}")
                print("Письмо будет отправлено без изображения")
        
        return message
    
    def _send_email_sync(self, to, subject, body, image_data=None):
        """Синхронная отправка письма"""
        message = self._create_message(to, subject, body, image_data)
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        
        try:
            send_request = (
                self.service.users()
                .messages()
                .send(userId="me", body={"raw": raw_message})
                .execute()
            )
            return send_request["id"]
        except HttpError as error:
            raise Exception(f"Gmail API error: {error}") from error
    
    async def send_email(self, to, subject, body, image_data=None):
        """
        Асинхронная отправка письма
        
        :param to: Email получателя
        :param subject: Тема письма (str)
        :param body: Текст сообщения (str)
        :param image_data: Base64 изображение в формате 
                           "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoA..." 
                           или None
        :return: ID отправленного сообщения
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._executor,
            self._send_email_sync,
            to, subject, body, image_data
        )
