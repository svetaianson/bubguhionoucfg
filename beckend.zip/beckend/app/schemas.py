from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email:    EmailStr
    password: str

class UserOut(BaseModel):
    id:    int
    email: EmailStr
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    email: str
    token_type: str = "bearer"
    status: str | None

class AnalyseOut(BaseModel):
    answer: str
    status: str

class AnalyseRequest(BaseModel):
    email: str | None   # ← было user_id
    image: str

class TraderRequest(BaseModel):
    id: str
    email: str | None

class TradingReviewRequest(BaseModel):
    email: str
    image: str
    text: str

class TradingReviewResponse(BaseModel):
    analysis: str
    status: str

class ChangePasswordRequest(BaseModel):
    currentPassword: str
    email: str
    newPassword: str