import base64
from openai import AsyncOpenAI

async def analyse_image(image_bytes: bytes) -> str:
    client = AsyncOpenAI(
        api_key="sk-e80232828dec4e7fb3af1a5a4f2a62eb",
        base_url="https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    )

    mime_type = "image/png"  # или определите динамически
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
    image_url = f"data:{mime_type};base64,{image_base64}"

    completion = await client.chat.completions.create(
        model="qwen-vl-plus",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a model for analyzing asset charts."
                    "Conduct an analysis and provide the probability of success."
                    "Submit your answer as JSON with the following fields:"
                    "'text' is your thoughts. Be sure to include the general trend in this field, 'probability' is the probability of success (a number from 50 to 100), and 'sol', which can be either SELL or BUY."
                    "Even if an error occurred, you must return everything in JSON format. You should not send anything other than JSON!"
                    "BUY advice to buy/go long. Keep in mind that if the market is rising, it should be BUY. SELL advice to sell/short. If the market is falling, it should be SELL."
                    "The percentage must be strictly between 50% and 100."
                ),
            },
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": image_url}},
                ],
            },
        ],
    )
    return completion.choices[0].message.content