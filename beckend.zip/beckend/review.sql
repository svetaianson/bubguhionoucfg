CREATE TABLE trading_reviews (
    id SERIAL PRIMARY KEY,
    email VARCHAR NOT NULL,
    chart_image VARCHAR(255) NULL,
    chart_notes VARCHAR(100) NULL,
    analysis_result TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы для оптимизации запросов
CREATE INDEX idx_trading_reviews_email ON trading_reviews(email);
CREATE INDEX idx_trading_reviews_created_at ON trading_reviews(created_at);